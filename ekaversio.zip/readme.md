# GITTREENI
---
## Yleistä
---
Tässä repossa Ohjelmistotuotanto-opintojakson peruskäsitteet-osan
* tehtävä 3
* tehtävä 4
---
## Osoitteet
---
Repositoryn osoite: (https://github.com/Antti-PekkaMakela/gittreeni)   
tämä repository voidaan kloonata komennolla  
```
git clone https://github.com/Antti-PekkaMakela/gittreeni.git
```
